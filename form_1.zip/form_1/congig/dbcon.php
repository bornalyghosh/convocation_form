<?php
// Database connection details
$host = "localhost";
$username = "root";
$password = "";
$dataname = "convocation";
//connect
$conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
// Function to sanitize and validate inputs
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Get form data
$name = sanitize_input($_POST['name']);
$s_id = sanitize_input($_POST['s_id']);
$batch = sanitize_input($_POST['dept']);
$dept = sanitize_input($_POST['batch']);
$address = sanitize_input($_POST['address']);
$email = sanitize_input($_POST['email']);
$password = sanitize_input($_POST['password']);
$pic = sanitize_input($_POST['pic']);

// Hash the password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Prepare SQL query with placeholders
$sql = "INSERT INTO users (name,s_id,dept,batch,address,email,password,pic,created_at) VALUES ('$name','$s_id','$batch','$dept','$address','$email','$password','$pic')";

// Prepare the statement
$stmt = mysqli_prepare($conn, $sql);

// Bind parameters to the statement
 mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $hashed_password);

// Execute the statement
 $result = mysqli_stmt_execute($stmt);


?>